<template>
  <div class="home">
    系统通知
    <footer-nav></footer-nav>
  </div>
</template>

<script>
import FooterNav from "../components/FooterNav"
export default {
  name: 'home',
  data(){
    return{
    
    }
  },
  components:{
    FooterNav,
  }
  
}
</script>
<style lang="stylus" scoped>
  @import "~@/assets/varibles.styl";
</style>

